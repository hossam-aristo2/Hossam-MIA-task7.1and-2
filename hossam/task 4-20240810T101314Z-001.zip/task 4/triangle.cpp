#include <iostream>
#include <iomanip>
using namespace std;
#include <bits/stdc++.h>
int max(int x,int y)
{
if(x>y){return x;}
else {return y;}
}
int findMin(int x, int y, int z) {
    return min(x, min(y, z));
}

int main(){
int a,b,c;
cin>>a>>b>>c;int counter=0;
int x=a+b>c&&b+c>a&&a+c>b;
findMin(a,b,c);
if(x){cout<<"0";}
else{
while(!x)
{
int min_side = findMin(a, b, c);
if (min_side == a) {
 a++;
 } else if (min_side == b) {
  b++;
} else {
   c++;
}
counter++;
x=a+b>c&&b+c>a&&a+c>b;
}
        cout << counter << endl;
    }

    return 0;
}