import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score


df = pd.read_csv(r"C:\weatherHistory.csv") 

df.columns = df.columns.str.strip()

numerical_features = [
    'Temperature (C)', 'Apparent Temperature (C)', 'Humidity',
    'Wind Speed (km/h)', 'Wind Bearing (degrees)', 'Visibility (km)',
    'Loud Cover', 'Pressure (millibars)'
]
data = df[numerical_features]

data = data.dropna()

X = data.drop('Temperature (C)', axis=1) 
y = data['Temperature (C)']  

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error: {mse:.2f}")
print(f"R-squared: {r2:.2f}")


new_data = pd.DataFrame({
    'Apparent Temperature (C)': [8.5],
    'Humidity': [0.75],
    'Wind Speed (km/h)': [12.0],
    'Wind Bearing (degrees)': [250],
    'Visibility (km)': [14.0],
    'Loud Cover': [0],
    'Pressure (millibars)': [1015]
})

temperature_prediction = model.predict(new_data)
print(f"Predicted Temperature: {temperature_prediction[0]:.2f} °C")
